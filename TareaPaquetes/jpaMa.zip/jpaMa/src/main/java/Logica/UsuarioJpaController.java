

package Logica;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Clases.Direccion;
import java.util.ArrayList;
import java.util.Collection;
import Clases.Titulo;
import Clases.Usuario;
import Logica.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author FerchoXxX
 */
public class UsuarioJpaController implements Serializable {

    public UsuarioJpaController() {
        this.emf =  Persistence.createEntityManagerFactory("JPAM");;;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Usuario usuario) {
        if (usuario.getDireccionCollection() == null) {
            usuario.setDireccionCollection(new ArrayList<Direccion>());
        }
        if (usuario.getTituloCollection() == null) {
            usuario.setTituloCollection(new ArrayList<Titulo>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Direccion> attachedDireccionCollection = new ArrayList<Direccion>();
            for (Direccion direccionCollectionDireccionToAttach : usuario.getDireccionCollection()) {
                direccionCollectionDireccionToAttach = em.getReference(direccionCollectionDireccionToAttach.getClass(), direccionCollectionDireccionToAttach.getIdDireccion());
                attachedDireccionCollection.add(direccionCollectionDireccionToAttach);
            }
            usuario.setDireccionCollection(attachedDireccionCollection);
            Collection<Titulo> attachedTituloCollection = new ArrayList<Titulo>();
            for (Titulo tituloCollectionTituloToAttach : usuario.getTituloCollection()) {
                tituloCollectionTituloToAttach = em.getReference(tituloCollectionTituloToAttach.getClass(), tituloCollectionTituloToAttach.getIdtitulo());
                attachedTituloCollection.add(tituloCollectionTituloToAttach);
            }
            usuario.setTituloCollection(attachedTituloCollection);
            em.persist(usuario);
            for (Direccion direccionCollectionDireccion : usuario.getDireccionCollection()) {
                Usuario oldRelacionOfDireccionCollectionDireccion = direccionCollectionDireccion.getRelacion();
                direccionCollectionDireccion.setRelacion(usuario);
                direccionCollectionDireccion = em.merge(direccionCollectionDireccion);
                if (oldRelacionOfDireccionCollectionDireccion != null) {
                    oldRelacionOfDireccionCollectionDireccion.getDireccionCollection().remove(direccionCollectionDireccion);
                    oldRelacionOfDireccionCollectionDireccion = em.merge(oldRelacionOfDireccionCollectionDireccion);
                }
            }
            for (Titulo tituloCollectionTitulo : usuario.getTituloCollection()) {
                Usuario oldRelacionOfTituloCollectionTitulo = tituloCollectionTitulo.getRelacion();
                tituloCollectionTitulo.setRelacion(usuario);
                tituloCollectionTitulo = em.merge(tituloCollectionTitulo);
                if (oldRelacionOfTituloCollectionTitulo != null) {
                    oldRelacionOfTituloCollectionTitulo.getTituloCollection().remove(tituloCollectionTitulo);
                    oldRelacionOfTituloCollectionTitulo = em.merge(oldRelacionOfTituloCollectionTitulo);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuario usuario) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario persistentUsuario = em.find(Usuario.class, usuario.getIdusuario());
            Collection<Direccion> direccionCollectionOld = persistentUsuario.getDireccionCollection();
            Collection<Direccion> direccionCollectionNew = usuario.getDireccionCollection();
            Collection<Titulo> tituloCollectionOld = persistentUsuario.getTituloCollection();
            Collection<Titulo> tituloCollectionNew = usuario.getTituloCollection();
            Collection<Direccion> attachedDireccionCollectionNew = new ArrayList<Direccion>();
            for (Direccion direccionCollectionNewDireccionToAttach : direccionCollectionNew) {
                direccionCollectionNewDireccionToAttach = em.getReference(direccionCollectionNewDireccionToAttach.getClass(), direccionCollectionNewDireccionToAttach.getIdDireccion());
                attachedDireccionCollectionNew.add(direccionCollectionNewDireccionToAttach);
            }
            direccionCollectionNew = attachedDireccionCollectionNew;
            usuario.setDireccionCollection(direccionCollectionNew);
            Collection<Titulo> attachedTituloCollectionNew = new ArrayList<Titulo>();
            for (Titulo tituloCollectionNewTituloToAttach : tituloCollectionNew) {
                tituloCollectionNewTituloToAttach = em.getReference(tituloCollectionNewTituloToAttach.getClass(), tituloCollectionNewTituloToAttach.getIdtitulo());
                attachedTituloCollectionNew.add(tituloCollectionNewTituloToAttach);
            }
            tituloCollectionNew = attachedTituloCollectionNew;
            usuario.setTituloCollection(tituloCollectionNew);
            usuario = em.merge(usuario);
            for (Direccion direccionCollectionOldDireccion : direccionCollectionOld) {
                if (!direccionCollectionNew.contains(direccionCollectionOldDireccion)) {
                    direccionCollectionOldDireccion.setRelacion(null);
                    direccionCollectionOldDireccion = em.merge(direccionCollectionOldDireccion);
                }
            }
            for (Direccion direccionCollectionNewDireccion : direccionCollectionNew) {
                if (!direccionCollectionOld.contains(direccionCollectionNewDireccion)) {
                    Usuario oldRelacionOfDireccionCollectionNewDireccion = direccionCollectionNewDireccion.getRelacion();
                    direccionCollectionNewDireccion.setRelacion(usuario);
                    direccionCollectionNewDireccion = em.merge(direccionCollectionNewDireccion);
                    if (oldRelacionOfDireccionCollectionNewDireccion != null && !oldRelacionOfDireccionCollectionNewDireccion.equals(usuario)) {
                        oldRelacionOfDireccionCollectionNewDireccion.getDireccionCollection().remove(direccionCollectionNewDireccion);
                        oldRelacionOfDireccionCollectionNewDireccion = em.merge(oldRelacionOfDireccionCollectionNewDireccion);
                    }
                }
            }
            for (Titulo tituloCollectionOldTitulo : tituloCollectionOld) {
                if (!tituloCollectionNew.contains(tituloCollectionOldTitulo)) {
                    tituloCollectionOldTitulo.setRelacion(null);
                    tituloCollectionOldTitulo = em.merge(tituloCollectionOldTitulo);
                }
            }
            for (Titulo tituloCollectionNewTitulo : tituloCollectionNew) {
                if (!tituloCollectionOld.contains(tituloCollectionNewTitulo)) {
                    Usuario oldRelacionOfTituloCollectionNewTitulo = tituloCollectionNewTitulo.getRelacion();
                    tituloCollectionNewTitulo.setRelacion(usuario);
                    tituloCollectionNewTitulo = em.merge(tituloCollectionNewTitulo);
                    if (oldRelacionOfTituloCollectionNewTitulo != null && !oldRelacionOfTituloCollectionNewTitulo.equals(usuario)) {
                        oldRelacionOfTituloCollectionNewTitulo.getTituloCollection().remove(tituloCollectionNewTitulo);
                        oldRelacionOfTituloCollectionNewTitulo = em.merge(oldRelacionOfTituloCollectionNewTitulo);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usuario.getIdusuario();
                if (findUsuario(id) == null) {
                    throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario usuario;
            try {
                usuario = em.getReference(Usuario.class, id);
                usuario.getIdusuario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuario with id " + id + " no longer exists.", enfe);
            }
            Collection<Direccion> direccionCollection = usuario.getDireccionCollection();
            for (Direccion direccionCollectionDireccion : direccionCollection) {
                direccionCollectionDireccion.setRelacion(null);
                direccionCollectionDireccion = em.merge(direccionCollectionDireccion);
            }
            Collection<Titulo> tituloCollection = usuario.getTituloCollection();
            for (Titulo tituloCollectionTitulo : tituloCollection) {
                tituloCollectionTitulo.setRelacion(null);
                tituloCollectionTitulo = em.merge(tituloCollectionTitulo);
            }
            em.remove(usuario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuario> findUsuarioEntities() {
        return findUsuarioEntities(true, -1, -1);
    }

    public List<Usuario> findUsuarioEntities(int maxResults, int firstResult) {
        return findUsuarioEntities(false, maxResults, firstResult);
    }

    private List<Usuario> findUsuarioEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuario.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuario findUsuario(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuario.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuarioCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuario> rt = cq.from(Usuario.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
