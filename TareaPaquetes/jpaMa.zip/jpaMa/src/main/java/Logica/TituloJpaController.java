

package Logica;

import Clases.Titulo;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import Clases.Usuario;
import Logica.exceptions.NonexistentEntityException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author FerchoXxX
 */
public class TituloJpaController implements Serializable {

    public TituloJpaController() {
        this.emf =  Persistence.createEntityManagerFactory("JPAM");;;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Titulo titulo) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuario relacion = titulo.getRelacion();
            if (relacion != null) {
                relacion = em.getReference(relacion.getClass(), relacion.getIdusuario());
                titulo.setRelacion(relacion);
            }
            em.persist(titulo);
            if (relacion != null) {
                relacion.getTituloCollection().add(titulo);
                relacion = em.merge(relacion);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Titulo titulo) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Titulo persistentTitulo = em.find(Titulo.class, titulo.getIdtitulo());
            Usuario relacionOld = persistentTitulo.getRelacion();
            Usuario relacionNew = titulo.getRelacion();
            if (relacionNew != null) {
                relacionNew = em.getReference(relacionNew.getClass(), relacionNew.getIdusuario());
                titulo.setRelacion(relacionNew);
            }
            titulo = em.merge(titulo);
            if (relacionOld != null && !relacionOld.equals(relacionNew)) {
                relacionOld.getTituloCollection().remove(titulo);
                relacionOld = em.merge(relacionOld);
            }
            if (relacionNew != null && !relacionNew.equals(relacionOld)) {
                relacionNew.getTituloCollection().add(titulo);
                relacionNew = em.merge(relacionNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = titulo.getIdtitulo();
                if (findTitulo(id) == null) {
                    throw new NonexistentEntityException("The titulo with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Titulo titulo;
            try {
                titulo = em.getReference(Titulo.class, id);
                titulo.getIdtitulo();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The titulo with id " + id + " no longer exists.", enfe);
            }
            Usuario relacion = titulo.getRelacion();
            if (relacion != null) {
                relacion.getTituloCollection().remove(titulo);
                relacion = em.merge(relacion);
            }
            em.remove(titulo);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Titulo> findTituloEntities() {
        return findTituloEntities(true, -1, -1);
    }

    public List<Titulo> findTituloEntities(int maxResults, int firstResult) {
        return findTituloEntities(false, maxResults, firstResult);
    }

    private List<Titulo> findTituloEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Titulo.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Titulo findTitulo(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Titulo.class, id);
        } finally {
            em.close();
        }
    }

    public int getTituloCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Titulo> rt = cq.from(Titulo.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

}
