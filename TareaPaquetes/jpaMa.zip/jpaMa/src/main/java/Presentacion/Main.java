

package Presentacion;

import Clases.Usuario;
import Logica.UsuarioJpaController;
import Logica.exceptions.NonexistentEntityException;
import java.util.Scanner;

/**
 *
 * @author FerchoXxX
 */
public class Main {
    
        private static UsuarioJpaController usuarioController = new UsuarioJpaController();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        boolean continuar = true;

        while (continuar) {
            System.out.println("Seleccione una opción:");
            System.out.println("1. Crear nuevo usuario");
            System.out.println("2. Leer usuario por ID");
            System.out.println("3. Actualizar usuario por ID");
            System.out.println("4. Eliminar usuario por ID");
            System.out.println("0. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer de entrada

            switch (opcion) {
                case 1:
                    crearUsuario();
                    break;
                case 2:
                    leerUsuarioPorId();
                    break;
                case 3:
                   actualizarUsuarioPorId();
                    break;
                case 4:
                    eliminarUsuarioPorId();
                    break;
                case 0:
                    continuar = false;
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
        scanner.close();
    }

    private static void crearUsuario() {
        Usuario nuevoUsuario = new Usuario();
        String campo;
        System.out.println("Ingrese el nombre del usuario: ");
        campo=scanner.nextLine();
        nuevoUsuario.setNombres(campo);
        System.out.println("Ingrese el apellido");
        campo=scanner.nextLine();
        nuevoUsuario.setApellidos(campo);
        usuarioController.create(nuevoUsuario);
        System.out.println("Usuario creado con ID: " + nuevoUsuario.getIdusuario());
    }

    private static void leerUsuarioPorId() {
        System.out.println("Ingrese el ID del usuario a buscar:");
        int usuarioId = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer de entrada

        Usuario usuarioLeido = usuarioController.findUsuario(usuarioId);
        if (usuarioLeido != null) {
            System.out.println("Usuario encontrado: " + usuarioLeido.getNombres() + " " + usuarioLeido.getApellidos());
        } else {
            System.out.println("Usuario no encontrado con ID: " + usuarioId);
        }
    }

    private static void actualizarUsuarioPorId() throws Exception {
        System.out.println("Ingrese el ID del usuario a actualizar:");
        int usuarioId = scanner.nextInt();
        String campo;
        scanner.nextLine(); // Limpiar el buffer de entrada

        Usuario usuarioLeido = usuarioController.findUsuario(usuarioId);
        if (usuarioLeido != null) {
            System.out.println("Usuario encontrado: " + usuarioLeido.getNombres() + " " + usuarioLeido.getApellidos());
            System.out.println("Ingrese el nuevo nombre:");
            campo = scanner.nextLine();
            usuarioLeido.setNombres(campo);
            System.out.println("Ingrese el nuevo apellido:");
            campo = scanner.nextLine();
            usuarioLeido.setApellidos(campo);
            usuarioController.edit(usuarioLeido);
            System.out.println("Usuario actualizado: " + usuarioLeido.getNombres() + " " + usuarioLeido.getApellidos());
        } else {
            System.out.println("Usuario no encontrado con ID: " + usuarioId);
        }
    }

    private static void eliminarUsuarioPorId() {
        System.out.println("Ingrese el ID del usuario a eliminar:");
        int usuarioId = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer de entrada

        try {
            usuarioController.destroy(usuarioId);
            System.out.println("Usuario eliminado correctamente.");
        } catch (NonexistentEntityException ex) {
            System.out.println("Error al intentar eliminar el usuario con ID: " + usuarioId);
        }
    }
    
}
