
package Clases;

public class Repartidor {
    
}
