
package Clases;

public class Empleados {
    
}
