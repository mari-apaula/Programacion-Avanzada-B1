
package Clases;


public class Estado {
    
}
